import os
from dotenv import load_dotenv

load_dotenv()

# ---------- Telegram ----------
API_ID     = int(os.getenv("API_ID", "0"))
API_HASH   = os.getenv("API_HASH", "")
BOT_TOKEN  = os.getenv("BOT_TOKEN", "")

# ---------- Игра ----------
CHANNEL    = os.getenv("CHANNEL", "@simroulette_news")
WEBAPP_URL = os.getenv("WEBAPP_URL", "https://example.com/")
WEBAPP_DIR = os.getenv("WEBAPP_DIR", "./webapp")
PORT       = int(os.getenv("PORT", "8080"))

# ---------- Админы ----------
ADMIN_IDS  = {
    int(x) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip().isdigit()
}

# ---------- Режим ----------
# DEV_MODE=1 — авторизация по uid без initData Telegram (тестирование вне Telegram)
DEV_MODE   = os.getenv("DEV_MODE", "1").strip() not in ("0", "false", "no")

# ---------- Прокси ----------
# Прокси отключён для локальной разработки (прямое подключение к Telegram)
PROXY = None

# ---------- Валидация ----------
def validate() -> list[str]:
    errs = []
    if not API_ID:    errs.append("API_ID не задан")
    if not API_HASH:  errs.append("API_HASH не задан")
    if not BOT_TOKEN: errs.append("BOT_TOKEN не задан")
    return errs